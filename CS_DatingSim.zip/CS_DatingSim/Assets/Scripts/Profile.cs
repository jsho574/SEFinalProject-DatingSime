﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Profile {
    private string characterName;
    private int textIndex;
    private int gameIndex;

}
